import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { MdDialogModule } from '@angular/material';
import { MdDatepickerModule, MdNativeDateModule} from '@angular/material';
import {  MdTooltipModule, MdTableModule, MdPaginator } from "@angular/material";

import {MdListModule} from '@angular/material';
import { MdProgressBarModule } from "@angular/material";
import {MdCheckboxModule} from '@angular/material';
import {MdProgressSpinnerModule} from '@angular/material';
import {MdSelectModule} from '@angular/material';
import {MdInputModule} from '@angular/material';
import {MdRadioModule} from '@angular/material';
import {DataTableModule} from "angular2-datatable";

import { MODULE_COMPONENTS, MODULE_ROUTES } from './dashboard.routes';
import { FooterComponent } from '../components/footer/footer.component';
import { NavbarComponent } from '../components/navbar/navbar.component';
import { SidebarComponent } from '../components/sidebar/sidebar.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface}  from 'ngx-perfect-scrollbar';


import { EditAdminComponent } from './edit-admin/edit-admin.component';
import { ViewSectionComponent } from './view-section/view-section.component';
import { DialogComponent} from './view-section/dialog/dialog.component';
import { AddSectionComponent } from './add-section/add-section.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { AddSubcategoryComponent } from './add-subcategory/add-subcategory.component';
import { AddContentComponent } from './add-content/add-content.component';
import { ViewContentComponent } from './view-content/view-content.component';
import { ViewDialogComponent } from './view-content/view-dialog/view-dialog.component';
import { HomepageComponent } from './homepage/homepage.component';
import { HomeDialogComponent } from './homepage/home-dialog/home-dialog.component';
import { PriorityComponent } from './priority/priority.component';
import { PriorityDialogComponent } from './priority/priority-dialog/priority-dialog.component';
import { CommentComponent } from './comment/comment.component';
import { UserContributionComponent } from './user-contribution/user-contribution.component';
import { UserComponent } from './user/user.component';
import { SectionAnalyticsComponent } from './section-analytics/section-analytics.component';
import { ArticleAnalyticsComponent } from './article-analytics/article-analytics.component';
import { ElementAnalyticsComponent } from './element-analytics/element-analytics.component';



const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
@NgModule({

    imports: [
        RouterModule.forChild(MODULE_ROUTES),
        PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
        MdDatepickerModule,
        MdNativeDateModule,
        MdTooltipModule,
        MdTableModule,
        DataTableModule,
         MdProgressBarModule,
        MdCheckboxModule,
        MdProgressSpinnerModule,
        MdSelectModule,
        MdInputModule,
        MdRadioModule,
        MdListModule

    ],
    declarations: [
              FooterComponent,
              NavbarComponent,
              SidebarComponent,
             MODULE_COMPONENTS,
             EditAdminComponent,
             ViewSectionComponent,
             DialogComponent,
             AddSectionComponent,
             AddCategoryComponent,
             AddSubcategoryComponent,
             AddContentComponent,
             ViewContentComponent,
             ViewDialogComponent,
             HomepageComponent,
             HomeDialogComponent,
             PriorityComponent,
             PriorityDialogComponent,
             CommentComponent,
             UserContributionComponent,
             UserComponent,
             SectionAnalyticsComponent,
             ArticleAnalyticsComponent,
             ElementAnalyticsComponent,
             
           ],

entryComponents: [ DialogComponent, ViewDialogComponent, HomeDialogComponent, PriorityDialogComponent  ],
})

export class DashboardModule{

}

