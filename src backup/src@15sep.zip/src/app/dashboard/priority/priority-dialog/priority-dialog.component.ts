import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-priority-dialog',
  templateUrl: './priority-dialog.component.html',
  styleUrls: ['./priority-dialog.component.scss']
})
export class PriorityDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
