import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-element-analytics',
  templateUrl: './element-analytics.component.html',
  styleUrls: ['./element-analytics.component.scss']
})
export class ElementAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
