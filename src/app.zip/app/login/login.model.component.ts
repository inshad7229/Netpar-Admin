
export class LoginModel {
      role:string;
      email:string;
      password:string;
      remember:any;
}
