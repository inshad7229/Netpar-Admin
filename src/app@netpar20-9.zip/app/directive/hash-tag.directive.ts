import { Directive, HostListener, OnInit }  from '@angular/core';
import { NgControl } from "@angular/forms";
import { HashTagPipe } from '../pipe/hash-tag.pipe'

@Directive({
  selector: '[appHashTag]'
})
export class HashTagDirective {
   private currencyPipe:HashTagPipe;

 constructor(private ngControl: NgControl) {
        this.currencyPipe = new HashTagPipe();
        alert('hello')
    }
 @HostListener("focus", ["$event.target.value"])
    onFocus(value) {
        // alert('hy')
        if (!this.ngControl) {
            return;
        }
        if(value==0.00 || value=='0.00'){
         this.ngControl.valueAccessor.writeValue(null);
        }else{
         this.ngControl.valueAccessor.writeValue(this.currencyPipe.parse(value));

        }
    }

    @HostListener("blur", ["$event.target.value"])
    onBlur(value) {
        alert('in drective')
        if (!this.ngControl) {
            return;
        }
        let transformed = this.currencyPipe.transform(value);
        this.ngControl.valueAccessor.writeValue(transformed);
        this.ngControl.viewToModelUpdate(Number(this.currencyPipe.parse(transformed)));
    }
}
