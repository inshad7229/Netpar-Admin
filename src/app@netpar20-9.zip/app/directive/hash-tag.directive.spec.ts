import { HashTagDirective } from './hash-tag.directive';

describe('HashTagDirective', () => {
  it('should create an instance', () => {
    const directive = new HashTagDirective();
    expect(directive).toBeTruthy();
  });
});
