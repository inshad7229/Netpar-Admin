import { Component, OnInit,ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastsManager , Toast} from 'ng2-toastr';
import {LoginModel} from './login.model.component';
import {LoginService} from './login.service'
import {AppProvider} from '../providers/app.provider'

declare var google : any;
const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[LoginService]
})
export class LoginComponent implements OnInit {
  complexForm: FormGroup;
  loginModel:LoginModel=new LoginModel();
  buttonStatus:boolean=false
 constructor(
         private router: Router,
         private fb: FormBuilder,
         private loginService:LoginService,
         public toastr: ToastsManager, 
         vcr: ViewContainerRef,
         private appProvider:AppProvider
       ) {
        this.complexForm = fb.group({
            'loginAs': [null, Validators.compose([Validators.required])],
            'password': [null, Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(15)])],
            'email': [null, Validators.compose([Validators.required, Validators.minLength(2),Validators.pattern(EMAIL_REGEX)])],
        }) 
        this.loginModel.role="superAdmin"
        this.toastr.setRootViewContainerRef(vcr);
 }
  ngOnInit() {
  }
 onLogIn(){
     this.buttonStatus=true
     this.loginService.onLogin(this.loginModel)
     .subscribe(data=>{
       this.buttonStatus=false
       if(data.success==false){
           this.toastr.error( 'Please check you login credential','Authentication failed. ',{toastLife: 3000, showCloseButton: true});
       }else if (data.success==true) {
          this.appProvider.current.loginData=data.response
          localStorage['token']=data.token
          console.log(localStorage['token'])
          this.toastr.success('successfully!', 'Success!', {toastLife: 3000, showCloseButton: true});
  	       this.router.navigate(['/home'],{ skipLocationChange: true });
       }
       console.log(JSON.stringify(data))
     })
  }
}
