
export class LoginModel {
      role:string;
      email:string;
      password:string;
}
