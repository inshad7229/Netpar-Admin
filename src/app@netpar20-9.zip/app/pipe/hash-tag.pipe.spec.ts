import { HashTagPipe } from './hash-tag.pipe';

describe('HashTagPipe', () => {
  it('create an instance', () => {
    const pipe = new HashTagPipe();
    expect(pipe).toBeTruthy();
  });
});
