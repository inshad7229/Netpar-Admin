
export class Current {
    adminData:any;
    adminPageFlag:any;
    loginData:any;

    constructor(public leadsFilter?: string) {
    }
}
