import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {
  color = '#00000';
  mode = 'determinate';
  value = 50;
  constructor() { }

  ngOnInit() {
  }

}
