import { ClipDirective } from './clip.directive';

describe('ClipDirective', () => {
  it('should create an instance', () => {
    const directive = new ClipDirective();
    expect(directive).toBeTruthy();
  });
});
